﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace War
{
    public partial class Info : Form
    {
        public Info()
        {
            InitializeComponent();
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
            Hide();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form Main_menu = new Main_menu();
            Main_menu.Show();
            toolStripButton1.Enabled = false;
            this.Visible = false;
        }
    }
}
