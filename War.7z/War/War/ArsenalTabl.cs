﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace War
{
    public partial class ArsenalTabl : Form
    {
        public ArsenalTabl()
        {
            InitializeComponent();
        }

        private void Arsenal_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "warDataSet.Weapon". При необходимости она может быть перемещена или удалена.
            this.weaponTableAdapter.Fill(this.warDataSet.Weapon);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
            Hide();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form Arsenal = new Arsenal();
            Arsenal.Show();
            toolStripButton1.Enabled = false;
            this.Visible = false;
        }
    }
}
