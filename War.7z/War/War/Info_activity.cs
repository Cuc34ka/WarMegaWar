﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace War
{
    public partial class Info_activity : Form
    {
        public Info_activity()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
            Hide();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form Info = new Info();
            Info.Show();
            toolStripButton1.Enabled = false;
            this.Visible = false;
        }
    }
}
