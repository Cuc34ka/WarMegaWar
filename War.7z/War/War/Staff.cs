﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace War
{
    public partial class Staff : Form
    {
        public Staff()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form StaffTabl = new StaffTabl();
            StaffTabl.Show();
            button1.Enabled = false;
            this.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            staffBindingSource.AddNew();
        }

        private void Staff_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "warDataSet.Staff". При необходимости она может быть перемещена или удалена.
            this.staffTableAdapter.Fill(this.warDataSet.Staff);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            staffBindingSource.RemoveCurrent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //проверяет введённые в поля данные на соответствие типам данных полей
            this.Validate();
            //закрывает подключение с сервером
            this.staffBindingSource.EndEdit();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
            Hide();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Form Main_menu = new Main_menu();
            Main_menu.Show();
            toolStripButton1.Enabled = false;
            this.Visible = false;
        }
    }
}
